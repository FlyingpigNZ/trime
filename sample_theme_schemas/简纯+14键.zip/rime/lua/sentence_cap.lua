-- 英文句子开头自动大写（首词/句号/感叹号/问号之后）
--
-- 在 engine/filters 里、en_spacer 之前，增加 - lua_filter@*sentence_cap
--
-- 行为：把当前英文候选的首字母大写，当满足以下任一条件：
--   1. 还没有任何已上屏内容（输入开头）—— 首词大写，如 Hello
--   2. 上一个已上屏文本以句末标点结尾（. ! ?，容忍尾随闭引号/括号/空白）—— 句末后大写
--
-- 受方案开关 smart_english 控制：关闭时本过滤为透传。
-- 与 en_spacer（给下一个词补前缀空格）配合：sentence_cap 先大写，en_spacer 再补空格。
--
-- 注意：melt_eng 是引擎驱动（ascii_mode 0），Trime 内置 auto_caps 不生效，
-- 所以用 Rime Lua 在候选翻译阶段做句首大写。

local function sentence_cap(input, env)
    if not env.engine.context:get_option( 'smart_english' ) then
        for cand in input:iter() do
            yield(cand)
        end
        return
    end
    local latest_text = env.engine.context.commit_history:latest_text()
    local at_start = latest_text == nil or #latest_text == 0
    local after_sentence = latest_text and #latest_text > 0 and
        latest_text:find("[%.%!%?][%)%]\"'%s]*$")
    local need_cap = at_start or after_sentence
    for cand in input:iter() do
        local c = cand
        if need_cap and
            c.text:match("^[%a]") and          -- 以字母开头
            not c.text:match("^[^%w]")          -- 首字符为字母数字（避免标点候选被改写）
        then
            c = c:to_shadow_candidate("sentence_cap", c.text:gsub("^%a", string.upper), c.comment)
        end
        yield(c)
    end
end

return sentence_cap
