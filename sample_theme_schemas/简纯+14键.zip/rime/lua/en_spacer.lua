-- 英文词条之间自动补空格（前缀空格方案，不给候选加尾空格）
-- 在 engine/filters 的倒数第二个位置，增加 - lua_filter@*en_spacer
--
-- 效果：当上一个已上屏内容是英文单词（或句子结束标点）时，给当前英文候选加一个前缀空格，
-- 提交后得到「hello world」或「hello. World」。候选本身不含尾随空格，所以标点前不会有多余空格。
--
-- 受方案开关 smart_english 控制：关闭时本过滤为透传。需放在 sentence_cap 之后。
local F = {}

function F.func( input, env )
    if not env.engine.context:get_option( 'smart_english' ) then
        for cand in input:iter() do
            yield( cand )
        end
        return
    end
    local latest_text = env.engine.context.commit_history:latest_text()
    for cand in input:iter() do
        local c = cand
        if c.text:match( '^[%a\']+[%a\']*$' ) and latest_text and #latest_text > 0 then
            local prev_is_word = latest_text:find( '^ ?[%a\']+[%a\']*$' )
            local prev_ends_sentence = latest_text:find( '[%.%!%?][%)%]\"\'%s]*$' )
            if prev_is_word or prev_ends_sentence then
                c = c:to_shadow_candidate( 'en_spacer', ' ' .. c.text, c.comment )
            end
        end
        yield( c )
    end
end

return F
