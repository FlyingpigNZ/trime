-- 英文词条上屏自动添加空格
-- 在 engine/filters 的倒数第二个位置，增加 - lua_filter@*en_spacer
-- 英文后，再输入英文单词（必须为候选项）自动添加空格
local F = {}

function F.func( input, env )
    local latest_text = env.engine.context.commit_history:latest_text()
    for cand in input:iter() do
        local c = cand
        if c.text:match( '^[%a\']+[%a\']*$' ) and latest_text and #latest_text > 0 and
            latest_text:find( '^ ?[%a\']+[%a\']*$' ) then
            c = c:to_shadow_candidate( 'en_spacer', c.text:gsub( '(%a+\'?%a*)', ' %1' ), c.comment )
        end
        yield( c )
    end
end

return F
