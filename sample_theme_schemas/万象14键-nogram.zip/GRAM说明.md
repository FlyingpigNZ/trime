# 万象14键 — 精简包（不含语法模型 .gram）

本 zip 为精简版，`rime/wanxiang-lts-zh-hans.gram` 是 **0 字节占位文件**，
真正的语法模型（约 400MB）需要手动补上。用于版本管理 / 快速分发。

## 使用方法

1. 下载语法模型 `wanxiang-lts-zh-hans.gram`（万象官方发布，约 400MB）
2. **覆盖** zip 内的占位文件 `rime/wanxiang-lts-zh-hans.gram`（0 字节）
3. 重新打包 zip（或在 trime 导入后把 .gram 放到 workspace 根目录）
4. 部署 Rime

> manifest.yaml 已包含 `rime/wanxiang-lts-zh-hans.gram` 条目，
> 补入 .gram 后无需修改 manifest。

## 为什么需要 .gram

本包的方案（`wanxiang_14jian` / `wanxiang_flypy` / `wanxiang_t9` / `wanxiang`）都在
`grammar.language: wanxiang-lts-zh-hans` 中引用该语法模型，用于语句流
整句联想。缺失时方案仍可输入，但没有整句预测能力。

## 本包内容

- `wanxiang_14jian.schema.yaml` — 小鹤双拼 14 键（主方案）
- `wanxiang_flypy.schema.yaml` — 小鹤双拼 26 键
- `wanxiang_t9.schema.yaml` — 万象九键（T9）
- `rime/` — 万象 base 词库（纯拼音无辅助码）+ Lua + 配置
- `keyboard.yaml` / `behavior.yaml` / `color.yaml` / `style.yaml` 等 — 14 键 / 9 键键盘与皮肤

## 版本

基于 `rime-wanxiang-base.zip`（万象 base 17.9.1，纯拼音无辅助码词库）。
